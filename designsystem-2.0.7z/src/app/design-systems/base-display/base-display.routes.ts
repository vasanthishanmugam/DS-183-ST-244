import {Routes} from '@angular/router';
import { BasicButtonComponent } from './components/basic-button/basic-button.component';
import { BasicButtonWithIconComponent } from './components/basic-button-with-icon/basic-button-with-icon.component';
import { FlatButtonWithIconComponent } from './components/flat-button-with-icon/flat-button-with-icon.component';
import { FlatButtonComponent } from './components/flat-button/flat-button.component';
import { RaisedButtonComponent } from './components/raised-button/raised-button.component';
import { RaisedButtonWithIconComponent } from './components/raised-button-with-icon/raised-button-with-icon.component';
import { StrokedButtonWithIconComponent } from './components/stroked-button-with-icon/stroked-button-with-icon.component';
import { StrokedButtonComponent } from './components/stroked-button/stroked-button.component';
import { FabButtonComponent } from './components/fab-button/fab-button.component';
import { FabButtonWithIconComponent } from './components/fab-button-with-icon/fab-button-with-icon.component';
import { IconButtonComponent } from './components/icon-button/icon-button.component';
import { BasicSliderComponent } from './components/basic-slider/basic-slider.component';
export const routes: Routes = [
    {
        path: '',
        redirectTo: 'basic-slider',
        pathMatch: 'full',
    },
    {
        path: 'basic-button',
        component: BasicButtonComponent
    },
    {
        path: 'basic-button-with-icon',
        component: BasicButtonWithIconComponent
    },
    {
        path: 'raised-button',
        component: RaisedButtonComponent
    },
    {
        path: 'raised-button-with-icon',
        component: RaisedButtonWithIconComponent
    },
    {
        path: 'flat-button',
        component: FlatButtonComponent
    },
    
    {
        path: 'flat-button-with-icon',
        component: FlatButtonWithIconComponent
    },
    {
        path: 'stroke-button',
        component: StrokedButtonComponent
    },
    {
        path: 'stroke-button-with-icon',
        component: StrokedButtonWithIconComponent
    },
    
    {
        path: 'fab-button',
        component: FabButtonComponent
    },
    {
        path: 'basic-slider',
        component: BasicSliderComponent
    }
];
