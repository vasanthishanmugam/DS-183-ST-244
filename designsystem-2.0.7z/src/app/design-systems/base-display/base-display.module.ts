import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonModule } from '~/app/base/button/button.module';
import { BaseDisplayRoutingModule } from './base-display-routing.module';
import { BasicButtonComponent } from './components/basic-button/basic-button.component';
import { BasicButtonWithIconComponent } from './components/basic-button-with-icon/basic-button-with-icon.component';
import { FlatButtonWithIconComponent } from './components/flat-button-with-icon/flat-button-with-icon.component';
import { FlatButtonComponent } from './components/flat-button/flat-button.component';
import { RaisedButtonComponent } from './components/raised-button/raised-button.component';
import { RaisedButtonWithIconComponent } from './components/raised-button-with-icon/raised-button-with-icon.component';
import { StrokedButtonWithIconComponent } from './components/stroked-button-with-icon/stroked-button-with-icon.component';
import { StrokedButtonComponent } from './components/stroked-button/stroked-button.component';
import { FabButtonComponent } from './components/fab-button/fab-button.component';
import { FabButtonWithIconComponent } from './components/fab-button-with-icon/fab-button-with-icon.component';
import { IconButtonComponent } from './components/icon-button/icon-button.component';
import { BasicSliderComponent } from './components/basic-slider/basic-slider.component';


@NgModule({
  declarations: [BasicButtonComponent, BasicButtonWithIconComponent, FlatButtonWithIconComponent, FlatButtonComponent, RaisedButtonComponent, RaisedButtonWithIconComponent, StrokedButtonWithIconComponent, StrokedButtonComponent, FabButtonComponent, FabButtonWithIconComponent, IconButtonComponent, BasicSliderComponent],
  imports: [
    CommonModule,
    BaseDisplayRoutingModule,
    ButtonModule
  ]
})
export class BaseDisplayModule { }
