import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flat-button-with-icon',
  templateUrl: './flat-button-with-icon.component.html',
  styleUrls: ['./flat-button-with-icon.component.scss']
})
export class FlatButtonWithIconComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
