import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-button-with-icon',
  templateUrl: './basic-button-with-icon.component.html',
  styleUrls: ['./basic-button-with-icon.component.scss']
})
export class BasicButtonWithIconComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
