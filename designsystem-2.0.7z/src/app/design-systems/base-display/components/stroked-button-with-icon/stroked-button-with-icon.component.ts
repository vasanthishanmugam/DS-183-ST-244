import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stroked-button-with-icon',
  templateUrl: './stroked-button-with-icon.component.html',
  styleUrls: ['./stroked-button-with-icon.component.scss']
})
export class StrokedButtonWithIconComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
