import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-raised-button-with-icon',
  templateUrl: './raised-button-with-icon.component.html',
  styleUrls: ['./raised-button-with-icon.component.scss']
})
export class RaisedButtonWithIconComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
