import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fab-button-with-icon',
  templateUrl: './fab-button-with-icon.component.html',
  styleUrls: ['./fab-button-with-icon.component.scss']
})
export class FabButtonWithIconComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
