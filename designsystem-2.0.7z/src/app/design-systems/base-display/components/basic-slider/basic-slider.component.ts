import { Component, OnInit,Input} from '@angular/core';
import { Slider } from "tns-core-modules/ui/slider";

@Component({
  selector: 'app-basic-slider',
  templateUrl: './basic-slider.component.html',
  styleUrls: ['./basic-slider.component.scss']
})
export class BasicSliderComponent implements OnInit {
  @Input() public minVal:any = "50";
  @Input() public maxVal:any ="200";
  @Input() public isDisabled ?: boolean = true;
  @Input() public btText ?: string = "Pressed";
  
  constructor() { }

  ngOnInit() {
  }
  public currentValue: number = 10;
  public fontSize: number = 20;

  public onSliderValueChange(args) {
      let slider = <Slider>args.object;
      this.currentValue = slider.value;
  }

  public onSecondSliderChange(args) {
      let slider = <Slider>args.object;
      this.fontSize = slider.value;
  }

  

}
