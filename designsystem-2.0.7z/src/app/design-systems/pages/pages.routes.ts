import {Routes} from '@angular/router';

export const routes: Routes = [
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full',
    },
    {
        path: '',
        loadChildren: () => import('~/app/design-systems/base-display/base-display.module').then(m => m.BaseDisplayModule) 
    }
];
