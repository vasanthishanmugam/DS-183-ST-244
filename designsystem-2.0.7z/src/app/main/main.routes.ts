import {Routes} from '@angular/router';
import { MainComponent } from './main/main.component';

export const routes: Routes = [
   
    {
        path: '',
        component: MainComponent,
        children:[
            {
                path: '',
                loadChildren: () => import('~/app/design-systems/base-display/base-display.module').then(m => m.BaseDisplayModule) 
   
                //loadChildren: () => import('~/app/design-systems/pages/pages.module').then(m => m.PagesModule)
            }
        ]
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full',
    }
    
];