import { Component, OnInit, Input } from '@angular/core';
import { MatSidenav } from '@angular/material';
interface Page {
  link: string;
  name: string;
  icon: string;
}
@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})

export class MainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }
  


}
