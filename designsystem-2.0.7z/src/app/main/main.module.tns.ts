import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';

import { MainRoutingModule } from './main-routing.module';
import { NativeScriptCommonModule } from 'nativescript-angular/common';

import { MainComponent } from './main/main.component';

@NgModule({
  declarations: [MainComponent],
  imports: [
    MainRoutingModule,
    NativeScriptCommonModule
  ],
  schemas: [NO_ERRORS_SCHEMA]
})
export class MainModule { }
