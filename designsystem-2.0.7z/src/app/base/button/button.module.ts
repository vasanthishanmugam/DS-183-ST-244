import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonRoutingModule } from './button-routing.module';
import { ButtonComponent } from './button/button.component';
import { MaterialModule }  from '../../material.module';
import { SliderComponent } from './slider/slider.component';

@NgModule({
  declarations: [ButtonComponent, SliderComponent],
  imports: [
    CommonModule,
    ButtonRoutingModule,
    MaterialModule
  ],
  exports: [ButtonComponent]
})
export class ButtonModule { 

  

}
