import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss']
})
export class ButtonComponent implements OnInit {
  @Input() public btColor ?: string;
  @Input() public btText ?: string;
  @Input() public isDisabled ?: boolean = false;
  @Input() public btnType ?: string;
  @Input() public btIcon ?: string;
  constructor() { }

  ngOnInit() {
  }


}
