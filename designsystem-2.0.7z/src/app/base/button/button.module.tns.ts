import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { ButtonRoutingModule } from './button-routing.module';
import { NativeScriptCommonModule } from 'nativescript-angular/common';
import { ButtonComponent } from './button/button.component';
import { SliderComponent } from './slider/slider.component';

@NgModule({
  declarations: [ButtonComponent, SliderComponent],
  imports: [
    ButtonRoutingModule,
    NativeScriptCommonModule
  ],
  exports: [ButtonComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class ButtonModule { }
