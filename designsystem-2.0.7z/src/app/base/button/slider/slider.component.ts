import { Component, OnInit, Input } from '@angular/core';
import { Slider } from "tns-core-modules/ui/slider";
@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.scss']
})
export class SliderComponent implements OnInit {
  @Input() public btColor ?: string;
  @Input() public btnType ?: string;
  @Input() public btIcon ?: string;
  @Input() public minVal:any = "50";
  @Input() public maxVal:any ="200";
  @Input() public isDisabled ?: boolean = true;
  @Input() public btText ?: string = "Pressed";
  
  constructor() { }

  ngOnInit() {
  }
  public currentValue: number = 10;
  public fontSize: number = 20;

  public onSliderValueChange(args) {
      let slider = <Slider>args.object;
      this.currentValue = slider.value;
  }

  public onSecondSliderChange(args) {
      let slider = <Slider>args.object;
      this.fontSize = slider.value;
  }

}
