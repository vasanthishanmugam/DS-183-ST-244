import {Routes} from '@angular/router';

export const routes: Routes = [
    {
        path: '',
        redirectTo: 'design-system',
        pathMatch: 'full',
    },
    {
        path: 'design-system',
        loadChildren: () => import('~/app/main/main.module').then(m => m.MainModule)
    },
];
