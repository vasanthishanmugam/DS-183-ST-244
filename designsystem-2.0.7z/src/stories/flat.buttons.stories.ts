import {storiesOf, moduleMetadata} from '@storybook/angular';

import { ButtonComponent } from '../app/base/button/button/button.component';
import { action } from '@storybook/addon-actions';
import { linkTo } from '@storybook/addon-links';
import { from } from 'rxjs';
import {PortalModule} from '@angular/cdk/portal';
import {ScrollingModule} from '@angular/cdk/scrolling';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatBadgeModule} from '@angular/material/badge';
import {MatBottomSheetModule} from '@angular/material/bottom-sheet';
import {MatButtonModule} from '@angular/material/button';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatCardModule} from '@angular/material/card';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatChipsModule} from '@angular/material/chips';
import {MatStepperModule} from '@angular/material/stepper';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatDialogModule} from '@angular/material/dialog';
import {MatDividerModule} from '@angular/material/divider';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatIconModule} from '@angular/material/icon';
import {MatInputModule} from '@angular/material/input';
import {MatListModule} from '@angular/material/list';
import {MatMenuModule} from '@angular/material/menu';
import {MatNativeDateModule, MatRippleModule} from '@angular/material/core';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatRadioModule} from '@angular/material/radio';
import {MatSelectModule} from '@angular/material/select';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatSliderModule} from '@angular/material/slider';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatSortModule} from '@angular/material/sort';
import {MatTableModule} from '@angular/material/table';
import {MatTabsModule} from '@angular/material/tabs';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatTreeModule} from '@angular/material/tree';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


storiesOf( 'Base/Flat Button', module)
.addDecorator(
  moduleMetadata({
      declarations: [
        ButtonComponent
      ],
      imports: [
          MatButtonModule,
          MatIconModule,
          MatBadgeModule
      ],
  }),
)
.add('Basic', () => ({
    component: ButtonComponent,
    props: {
      btColor: 'basic',
      btText: 'Basic',
      btnType:'flatButton'
    },
  }))
  .add('Primary', () => ({
    component: ButtonComponent,
    props: {
      btColor: 'primary',
      btText: 'Primary',
      btnType:'flatButton'
    },
  }))
  .add('Accent', () => ({
    component: ButtonComponent,
    props: {
      btColor: 'accent',
      btText: 'Accent',
      btnType:'flatButton'
    },
  }))
  .add('Warn', () => ({
    component: ButtonComponent,
    props: {
      btColor: 'warn',
      btText: 'Warn',
      btnType:'flatButton'
    },
  }))
  .add('Disabled', () => ({
    component: ButtonComponent,
    props: {
      btColor: 'accent',
      btText: 'Disabled',
      isDisabled: true,
      btnType:'flatButton'
    },
  }))
  .add('Link', () => ({
    component: ButtonComponent,
    props: {
      btColor: 'basic',
      btText: 'Link',
      btnType:'flatButton'
    },
  }))
  
.add('Icon - Basic', () => ({
    component: ButtonComponent,
    props: {
      btColor: 'basic',
      btText: 'Basic',
      btnType:'flatButton',
      btIcon: 'list-ul'
    },
  }))
  .add('Icon - Primary', () => ({
    component: ButtonComponent,
    props: {
      btColor: 'primary',
      btText: 'Primary',
      btnType:'flatButton',
      btIcon: 'list-ul'
    },
  }))
  .add('Icon - Accent', () => ({
    component: ButtonComponent,
    props: {
      btColor: 'accent',
      btText: 'Accent',
      btnType:'flatButton',
      btIcon: 'list-ul'
    },
  }))
  .add('Icon - Warn', () => ({
    component: ButtonComponent,
    props: {
      btColor: 'warn',
      btText: 'Warn',
      btnType:'flatButton',
      btIcon: 'list-ul'
    },
  }))
  .add('Icon - Disabled', () => ({
    component: ButtonComponent,
    props: {
      btColor: 'accent',
      btText: 'Disabled',
      isDisabled: true,
      btnType:'flatButton',
      btIcon: 'list-ul'
    },
  }))
  .add('Icon - Link', () => ({
    component: ButtonComponent,
    props: {
      btColor: 'basic',
      btText: 'Link',
      btnType:'flatButton',
      btIcon: 'list-ul'
    },
  }));
;