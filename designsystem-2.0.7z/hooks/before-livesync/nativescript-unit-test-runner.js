module.exports = require("nativescript-unit-test-runner/lib/before-liveSync.js");
