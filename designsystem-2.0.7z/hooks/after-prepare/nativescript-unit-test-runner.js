module.exports = require("nativescript-unit-test-runner/./lib/after-prepare.js");
